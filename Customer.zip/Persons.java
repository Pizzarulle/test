public class Persons {
	private String customer_id, customer_name, address, country, city;

	public Persons() {
	}

	public Persons(String address, String country, String city) 
	{
		setCustomer_id(customer_id);
		setCustomer_name(customer_name);
		setAddress(address);
		setCountry(country);
		setCity(city);
	}

	public String getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}

	public String getCustomer_name() 
	{
		return customer_name;
	}

	public void setCustomer_name(String customer_name) 
	{
		this.customer_name = customer_name;
	}

	public String getAddress() 
	{
		return address;
	}

	public void setAddress(String address) 
	{
		this.address = address;
	}

	public String getCountry() 
	{
		return country;
	}

	public void setCountry(String country) 
	{
		this.country = country;
	}

	public String getCity() 
	{
		return city;
	}

	public void setCity(String city) 
	{
		this.city = city;
	}

	public String toString() 
	{
		return "Customer [customer=" + customer_id + "name=" + customer_name + "address=" + address + ", country=" + country + ", city="
				+ city + "]";
	}

}
