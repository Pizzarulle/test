import java.sql.SQLException;

public class Main {

	public static void main(String[] args) throws SQLException {


		Customer customer = new Customer("Customer");

		for(String p: customer.getCustomer())
		{
			for(Persons c: customer.getCustomerInfo()) {
				System.out.println(p + c);
			}
		}

	}
}