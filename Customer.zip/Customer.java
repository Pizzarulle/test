import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jdbc.JDBCConnector;


public class Customer {
	private static ResultSet res = null;
	private static String customer_id;

	public Customer(String customerId) 
	{
		Customer.customer_id = customerId;
	}

	public  List<String> getCustomer() throws SQLException 
	{
		List<String> customers = new ArrayList<String>();

		res = JDBCConnector.getInstance().createStatement
				("select from customer  " + "concat(first_name, ' ', last_name) as name "
						+ "customer.customer_id, ")
				.executeQuery();
		
		while (res.next()) {
			customers.add(res.getString(1));
		}
		return customers;
	}

	public  List<Persons> getCustomerInfo() throws SQLException 
	{
		List<Persons> customerInfo = new ArrayList<Persons>();

		res = JDBCConnector.getInstance().createStatement
				("select "
						+"concat(city.city,', country.country,', address.address) as address, " 
						+"from customer " + "	inner join address on customer.address_id = address.address_id "							
						+"inner join city on address.city_id = city.city_id "
						+"inner join country on city.country_id = country.country_id ")
				.executeQuery();

		while (res.next()) 
		{
			customerInfo.add(new Persons(res.getString(1), res.getString(2), res.getString(3)));
		}

		return customerInfo;
	}

}